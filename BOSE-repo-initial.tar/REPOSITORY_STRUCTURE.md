# BOSE Method GitHub Repository Structure

## Recommended Directory Structure

```
BOSE-method/
│
├── README.md                           # Main project documentation
├── LICENSE                             # MIT License
├── .gitignore                          # Git ignore file
│
├── R/                                  # Core R package functions
│   ├── bose_core.R                     # Main BOSE estimation functions
│   ├── type1_indices.R                 # Type 1 quantile index calculations
│   ├── posterior_sampling.R            # Bayesian posterior sampling
│   └── helper_functions.R              # Utility functions
│
├── simulations/                        # Simulation study code
│   ├── run_simulation_type1.R          # Main simulation script (Type 1)
│   ├── simulation_functions.R          # Simulation helper functions
│   └── results/                        # Simulation output directory
│       └── .gitkeep                    # Keep empty folder in git
│
├── case_studies/                       # Real data analysis
│   ├── real_data_analysis.R            # Main real data analysis script
│   ├── skewness_assessment.R           # Skewness calculation functions
│   └── contour_plots.R                 # Contour visualization functions
│
├── visualization/                      # Plotting and visualization
│   ├── shiny_app.R                     # Interactive Shiny application
│   ├── plot_rmse.R                     # RMSE plotting functions
│   ├── plot_coverage.R                 # Coverage plotting functions
│   └── plot_utilities.R                # Shared plotting utilities
│
├── data/                               # Example datasets
│   ├── example_studies.csv             # Sample meta-analysis data
│   └── simulation_results_sample.rds   # Sample simulation results
│
├── inst/                               # Installed files (R package standard)
│   ├── shiny/                          # Shiny app deployment
│   │   └── app.R                       # Standalone Shiny app
│   └── examples/                       # Example scripts
│       ├── quick_start.R               # Minimal working example
│       └── full_workflow.R             # Complete analysis workflow
│
├── vignettes/                          # Long-form documentation
│   ├── introduction.Rmd                # Getting started guide
│   ├── type1_vs_type7.Rmd              # Quantile type comparison
│   └── real_data_tutorial.Rmd          # Real data analysis tutorial
│
├── docs/                               # Documentation website (pkgdown)
│   └── index.html                      # Auto-generated documentation
│
├── tests/                              # Unit tests (testthat)
│   ├── testthat.R                      # Test runner
│   └── testthat/
│       ├── test_bose_core.R            # Core function tests
│       └── test_indices.R              # Index calculation tests
│
├── manuscript/                         # Paper-related materials
│   ├── supplementary_code.R            # Code for paper figures/tables
│   └── supplementary_materials.pdf     # Supplementary document
│
├── DESCRIPTION                         # R package metadata
├── NAMESPACE                           # Package namespace (auto-generated)
└── _pkgdown.yml                        # Documentation website config
```

## File Organization Rationale

### Core Functions (`R/`)
**Purpose**: Reusable, well-documented R functions
- `bose_core.R`: Main estimation functions that users will call
- `type1_indices.R`: Type 1 quantile index calculations (critical finding)
- `posterior_sampling.R`: Adaptive grid-based Bayesian sampling
- `helper_functions.R`: Utility functions (MSE, ARE, etc.)

### Simulations (`simulations/`)
**Purpose**: Reproducible simulation studies
- Extract simulation logic from `Simulation_Type1.R` into modular functions
- Separate computation from result processing
- Results folder for storing outputs (use `.gitkeep` to track empty folders)

### Case Studies (`case_studies/`)
**Purpose**: Real-world applications
- Separate skewness assessment functions from analysis
- Modularize contour plot generation
- Make it easy for others to apply to their own data

### Visualization (`visualization/`)
**Purpose**: All plotting and interactive tools
- Shiny app for interactive exploration
- Separate plotting functions by purpose (RMSE, coverage, etc.)
- Reusable theme/style components

### Documentation (`vignettes/`, `docs/`)
**Purpose**: User-facing tutorials and guides
- Vignettes: Step-by-step tutorials in RMarkdown
- Docs: Auto-generated website using pkgdown

## Files to Upload

### Priority 1: Essential (Upload First)
1. `README.md` - Project overview
2. `LICENSE` - MIT License
3. Core functions in `R/`
4. At least one working example in `inst/examples/`

### Priority 2: Reproducibility (Upload Second)
1. Simulation code (refactored)
2. Real data analysis (refactored)
3. Example datasets in `data/`

### Priority 3: Enhancement (Upload Third)
1. Shiny app
2. Vignettes
3. Tests
4. Manuscript supplementary materials

## What NOT to Upload
- Personal file paths (e.g., `/Users/lydia/Desktop/...`)
- Large result files (>100MB) - use `.gitignore`
- Intermediate/temporary files
- Your personal `outpath` directories

## Next Steps
1. I'll refactor your code files into this structure
2. Translate all Chinese comments to English
3. Remove hardcoded paths
4. Add proper documentation
5. Create example README.md
